/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  darkMode: "class",
  theme: {
    extend: {
      fontFamily: {
        display: ["'Fraunces'", "'Playfair Display'", "serif"],
        sans: ["'Manrope'", "system-ui", "sans-serif"],
        mono: ["'JetBrains Mono'", "ui-monospace", "monospace"]
      },
      colors: {
        // Semantic tokens — driven by CSS variables in index.css
        bg: "rgb(var(--bg) / <alpha-value>)",
        fg: "rgb(var(--fg) / <alpha-value>)",
        elev: "rgb(var(--elev) / var(--elev-alpha, 0.6))",
        line: "rgb(var(--line) / var(--line-alpha, 0.10))",
        accent: "rgb(var(--accent) / <alpha-value>)",
        accent2: "rgb(var(--accent2) / <alpha-value>)",
        accent3: "rgb(var(--accent3) / <alpha-value>)"
      },
      animation: {
        "marquee": "marquee 40s linear infinite",
        "shimmer": "shimmer 7s linear infinite",
        "aurora": "auroraShift 18s ease-in-out infinite",
        "pulse-ring": "pulseRing 2.6s ease-out infinite"
      },
      keyframes: {
        marquee: {
          "0%": { transform: "translateX(0)" },
          "100%": { transform: "translateX(-50%)" }
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 50%" },
          "100%": { backgroundPosition: "200% 50%" }
        },
        auroraShift: {
          "0%, 100%": { transform: "translate3d(-12%, -8%, 0) rotate(0deg) scale(1)" },
          "50%": { transform: "translate3d(10%, 8%, 0) rotate(20deg) scale(1.15)" }
        },
        pulseRing: {
          "0%": { transform: "scale(.8)", opacity: ".8" },
          "100%": { transform: "scale(1.7)", opacity: "0" }
        }
      }
    }
  },
  plugins: []
};
