import React, { useEffect, useRef, useState, useMemo } from "react";
import { motion, useScroll, useTransform, useSpring, useMotionValue, useInView, AnimatePresence } from "framer-motion";

/* ────────────────────────────────────────────────────────────────────
   SplitText — letters reveal on view (React Bits style)
   ──────────────────────────────────────────────────────────────────── */
export function SplitText({ children, className = "", delay = 0, stagger = 0.03, as: Tag = "span" }) {
  const text = String(children);
  const words = text.split(" ");

  return (
    <Tag className={className} aria-label={text}>
      {words.map((word, wi) => (
        <span key={wi} className="inline-block whitespace-nowrap">
          {word.split("").map((char, ci) => (
            <motion.span
              key={ci}
              className="inline-block"
              initial={{ y: "120%", opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{
                duration: 0.7,
                ease: [0.2, 0.8, 0.2, 1],
                delay: delay + (wi * 4 + ci) * stagger
              }}
            >
              {char}
            </motion.span>
          ))}
          {wi < words.length - 1 && <span className="inline-block">&nbsp;</span>}
        </span>
      ))}
    </Tag>
  );
}

/* ────────────────────────────────────────────────────────────────────
   ShinyText — gradient shimmer sweep
   ──────────────────────────────────────────────────────────────────── */
export function ShinyText({ children, className = "" }) {
  return <span className={`text-shimmer ${className}`}>{children}</span>;
}

/* ────────────────────────────────────────────────────────────────────
   BlurReveal — fade-up + blur on view
   ──────────────────────────────────────────────────────────────────── */
export function BlurReveal({ children, delay = 0, className = "" }) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 24, filter: "blur(12px)" }}
      whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
      viewport={{ once: true, amount: 0.15, margin: "0px 0px -10% 0px" }}
      transition={{ duration: 0.9, ease: [0.2, 0.8, 0.2, 1], delay }}
    >
      {children}
    </motion.div>
  );
}

/* ────────────────────────────────────────────────────────────────────
   TiltCard — 3D magnetic tilt (React Bits style)
   ──────────────────────────────────────────────────────────────────── */
export function TiltCard({ children, className = "", intensity = 8 }) {
  const ref = useRef(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const rotateX = useSpring(useTransform(y, [-0.5, 0.5], [intensity, -intensity]), { stiffness: 220, damping: 22 });
  const rotateY = useSpring(useTransform(x, [-0.5, 0.5], [-intensity, intensity]), { stiffness: 220, damping: 22 });

  const onMove = (e) => {
    const r = ref.current.getBoundingClientRect();
    x.set((e.clientX - r.left) / r.width - 0.5);
    y.set((e.clientY - r.top) / r.height - 0.5);
  };
  const onLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <motion.div
      ref={ref}
      className={className}
      style={{ rotateX, rotateY, transformStyle: "preserve-3d", transformPerspective: 1200 }}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
    >
      {children}
    </motion.div>
  );
}

/* ────────────────────────────────────────────────────────────────────
   MagnetButton — pointer-following micro-magnetism
   ──────────────────────────────────────────────────────────────────── */
export function MagnetButton({ children, className = "", strength = 14, ...props }) {
  const ref = useRef(null);
  const x = useSpring(0, { stiffness: 300, damping: 18 });
  const y = useSpring(0, { stiffness: 300, damping: 18 });

  const onMove = (e) => {
    const r = ref.current.getBoundingClientRect();
    x.set(((e.clientX - (r.left + r.width / 2)) / r.width) * strength * 2);
    y.set(((e.clientY - (r.top + r.height / 2)) / r.height) * strength * 2);
  };
  const onLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <motion.a
      ref={ref}
      style={{ x, y }}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      className={className}
      {...props}
    >
      {children}
    </motion.a>
  );
}

/* ────────────────────────────────────────────────────────────────────
   ParticleField — animated dots with linkages (canvas)
   ──────────────────────────────────────────────────────────────────── */
export function ParticleField({ density = 60, hue = "180,80%,70%" }) {
  const ref = useRef(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    let raf = 0;
    let w = 0, h = 0;
    let particles = [];

    const reset = () => {
      const dpr = window.devicePixelRatio || 1;
      w = canvas.offsetWidth;
      h = canvas.offsetHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = Math.min(density, Math.max(20, Math.floor(w / 14)));
      particles = Array.from({ length: count }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.35,
        vy: (Math.random() - 0.5) * 0.35,
        r: 0.7 + Math.random() * 1.6
      }));
    };

    const draw = () => {
      ctx.clearRect(0, 0, w, h);
      particles.forEach((p, i) => {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0 || p.x > w) p.vx *= -1;
        if (p.y < 0 || p.y > h) p.vy *= -1;

        ctx.fillStyle = `hsla(${hue}, 0.9)`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();

        for (let j = i + 1; j < particles.length; j++) {
          const o = particles[j];
          const d = Math.hypot(p.x - o.x, p.y - o.y);
          if (d < 110) {
            ctx.strokeStyle = `hsla(${hue}, ${0.18 * (1 - d / 110)})`;
            ctx.lineWidth = 0.7;
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(o.x, o.y);
            ctx.stroke();
          }
        }
      });
      raf = requestAnimationFrame(draw);
    };

    reset();
    draw();
    window.addEventListener("resize", reset);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", reset);
    };
  }, [density, hue]);

  return <canvas ref={ref} className="pointer-events-none absolute inset-0 h-full w-full" />;
}

/* ────────────────────────────────────────────────────────────────────
   AuroraBackground — slow drifting conic-gradient blob
   ──────────────────────────────────────────────────────────────────── */
export function AuroraBackground() {
  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden bg-bg">
      {/* Soft radial accents — uses theme accent colors */}
      <div
        className="absolute inset-0 opacity-60"
        style={{
          backgroundImage:
            "radial-gradient(circle at 18% 18%, rgb(var(--accent2) / 0.18), transparent 30%), \
             radial-gradient(circle at 82% 22%, rgb(var(--accent3) / 0.16), transparent 28%), \
             radial-gradient(circle at 50% 88%, rgb(var(--accent) / 0.12), transparent 32%)"
        }}
      />
      {/* Aurora conic blob */}
      <div
        className="absolute left-1/2 top-1/2 h-[55rem] w-[55rem] -translate-x-1/2 -translate-y-1/2 rounded-full blur-3xl opacity-60"
        style={{
          background:
            "conic-gradient(from 90deg, rgb(var(--accent2) / 0.18), rgb(var(--accent3) / 0.20), rgb(var(--accent) / 0.14), rgb(var(--accent2) / 0.18))",
          animation: "auroraShift 22s ease-in-out infinite"
        }}
      />
      {/* Grid */}
      <div
        className="absolute inset-0 opacity-[0.05]"
        style={{
          backgroundImage:
            "linear-gradient(rgb(var(--fg) / 0.7) 1px, transparent 1px), \
             linear-gradient(90deg, rgb(var(--fg) / 0.7) 1px, transparent 1px)",
          backgroundSize: "64px 64px"
        }}
      />
      {/* Grain */}
      <div className="grain" />
    </div>
  );
}

/* ────────────────────────────────────────────────────────────────────
   Marquee — horizontally scrolling row of items
   ──────────────────────────────────────────────────────────────────── */
export function Marquee({ items, className = "" }) {
  // Build one "track" of items — duplicate the track twice so translate(-50%) loops seamlessly
  const Track = ({ ariaHidden = false }) => (
    <div className="flex shrink-0 items-center gap-10 pr-10" aria-hidden={ariaHidden}>
      {items.map((item, i) => (
        <React.Fragment key={i}>
          <span className="font-display text-[clamp(2.5rem,6vw,5rem)] font-light tracking-[-0.04em] text-fg/90">
            {item}
          </span>
          <span className="text-accent text-3xl">✦</span>
        </React.Fragment>
      ))}
    </div>
  );

  return (
    <div className={`relative w-full overflow-hidden mask-fade-x ${className}`}>
      <div className="marquee-track flex whitespace-nowrap will-change-transform">
        <Track />
        <Track ariaHidden />
      </div>
    </div>
  );
}

/* ────────────────────────────────────────────────────────────────────
   Counter — animated number on view (React Bits CountUp style)
   ──────────────────────────────────────────────────────────────────── */
export function Counter({ value, className = "" }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true });
  const [display, setDisplay] = useState(value);

  useEffect(() => {
    if (!inView) return;
    // If non-numeric (e.g. "24/26"), just show as-is
    const numeric = String(value).match(/^\d+$/);
    if (!numeric) {
      setDisplay(value);
      return;
    }
    const target = parseInt(value, 10);
    const start = performance.now();
    const dur = 1200;
    let raf = 0;
    const tick = (t) => {
      const p = Math.min(1, (t - start) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      const cur = Math.round(eased * target);
      setDisplay(String(cur).padStart(String(target).length, "0"));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, value]);

  return (
    <span ref={ref} className={className}>
      {display}
    </span>
  );
}

/* ────────────────────────────────────────────────────────────────────
   Cursor — soft glow follower
   ──────────────────────────────────────────────────────────────────── */
export function CursorGlow() {
  const x = useMotionValue(-200);
  const y = useMotionValue(-200);
  const sx = useSpring(x, { stiffness: 220, damping: 22 });
  const sy = useSpring(y, { stiffness: 220, damping: 22 });

  useEffect(() => {
    const move = (e) => {
      x.set(e.clientX);
      y.set(e.clientY);
    };
    window.addEventListener("mousemove", move);
    return () => window.removeEventListener("mousemove", move);
  }, [x, y]);

  return (
    <motion.div
      style={{
        x: sx,
        y: sy,
        translateX: "-50%",
        translateY: "-50%",
        background:
          "radial-gradient(circle, rgb(var(--accent2) / 0.7), rgb(var(--accent3) / 0.5) 40%, rgb(var(--accent) / 0.3) 70%, transparent 100%)"
      }}
      className="pointer-events-none fixed left-0 top-0 z-[60] h-[400px] w-[400px] rounded-full opacity-[0.10] blur-3xl"
    />
  );
}

/* ────────────────────────────────────────────────────────────────────
   ScrollProgress — top progress bar
   ──────────────────────────────────────────────────────────────────── */
export function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 120, damping: 20 });
  return (
    <motion.div
      className="fixed left-0 top-0 z-50 h-[2px] w-full origin-left"
      style={{
        scaleX,
        background:
          "linear-gradient(90deg, rgb(var(--accent2)), rgb(var(--accent3)), rgb(var(--accent)))"
      }}
    />
  );
}

export { motion, AnimatePresence, useInView };
