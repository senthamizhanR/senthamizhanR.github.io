// All CV content in one place

export const profile = {
  name: "R. Senthamizhan",
  title: "Researcher · Nonlinear Dynamics & Mathematical Physics",
  affiliation: "Project Associate – I, ANRF · SASTRA Deemed University",
  location: "Thanjavur, Tamil Nadu, India",
  email: "senthamizhan.phy@gmail.com",
  altEmail: "astrothamizh@gmail.com",
  phone: "+91 73977 00920",
  summary:
    "I am a physics researcher working at the intersection of nonlinear dynamics and mathematical physics. My work focuses on swarmalator systems — populations of agents that simultaneously sync in phase and aggregate in space — exploring chimera states, higher-order harmonics, frustration effects and data-driven analyses of collective behaviour.",
  scholar: "https://scholar.google.com/citations?user=qr-JN2cAAAAJ&hl=en",
  orcid: "https://orcid.org/0009-0000-0669-3336",
  github: "https://github.com/senthamizhanR/",
  heroTimeline: "Researcher · 2022 – Present"
};

export const navLinks = [
  { label: "Index", href: "#top" },
  { label: "Research", href: "#research" },
  { label: "Papers", href: "#publications" },
  { label: "Work", href: "#projects" },
  { label: "CV", href: "#cv" },
  { label: "Contact", href: "#contact" }
];

export const metrics = [
  { value: "03", label: "Peer-reviewed papers" },
  { value: "03", label: "Conferences" },
  { value: "01", label: "Best poster award" },
  { value: "24/26", label: "ANRF tenure" }
];

export const marqueeItems = [
  "Nonlinear dynamics",
  "Mathematical physics",
  "Swarmalators",
  "Synchronization",
  "Chimera states",
  "Complex systems",
  "Scientific computing",
  "High-performance computing"
];

export const researchInterests = [
  "Swarmalators",
  "Synchronization",
  "Chimera states",
  "Complex systems"
];

export const skills = [
  { group: "Languages", items: ["C", "Python", "FORTRAN 90/95"] },
  { group: "Writing", items: ["LaTeX"] },
  { group: "Tooling", items: ["GIMP", "Linux", "CUDA"] },
  { group: "Currently", items: ["LLM stack", "Scientific ML", "Simulation"] }
];

export const education = [
  {
    degree: "M.Sc. Physics",
    institution: "SASTRA Deemed University · Thanjavur",
    years: "2019 – 2021",
    score: "GPA 7.89 / 10",
    details:
      "Advanced coursework in physics with analytical, numerical and computational training. M.Sc. project: Within-burst synchrony change among coupled elliptic bursters."
  },
  {
    degree: "B.Sc. Physics & Computer Science",
    institution: "SASTRA · Srinivasa Ramanujan Centre, Kumbakonam",
    years: "2016 – 2019",
    score: "GPA 7.06 / 10",
    details:
      "Dual-major degree combining physics with computer science — programming languages, coding methodologies and computational problem solving."
  }
];

export const publications = [
  {
    title: "Data-driven exploration of swarmalators with second-order harmonics",
    authors: "R. Senthamizhan, R. Gopal & V. K. Chandrasekar",
    venue: "Physical Review E",
    cite: "109(6), 064303",
    year: "2024",
    status: "Published",
    doi: "10.1103/PhysRevE.109.064303",
    href: "https://doi.org/10.1103/PhysRevE.109.064303",
    tag: "PRE"
  },
  {
    title: "Frustration-induced chimeras and motion in two-dimensional swarmalators",
    authors: "R. Senthamizhan, R. Gopal & V. K. Chandrasekar",
    venue: "Chaos, Solitons & Fractals",
    cite: "194, 116164",
    year: "2025",
    status: "Published",
    doi: "10.1016/j.chaos.2025.116164",
    href: "https://doi.org/10.1016/j.chaos.2025.116164",
    tag: "CSF"
  },
  {
    title: "Swarmalators with frequency-weighted interactions",
    authors: "R. Senthamizhan, R. Gopal & V. K. Chandrasekar",
    venue: "Physical Review E",
    cite: "113, 034216",
    year: "2026",
    status: "Published",
    doi: "10.1103/dhz7-p4yg",
    href: "https://doi.org/10.1103/dhz7-p4yg",
    tag: "PRE"
  }
];

export const projects = [
  {
    n: "01",
    title: "Frequency-weighted Kuramoto model under biharmonic coupling",
    description:
      "A theoretical exploration of the frequency-weighted Kuramoto model under biharmonic coupling — investigating how the second harmonic in pairwise interactions reshapes synchronization thresholds, hysteresis and emergent collective states.",
    tags: ["Kuramoto", "Biharmonic", "Theory"]
  },
  {
    n: "02",
    title: "Data-driven nonlinear dynamics",
    description:
      "Computational and data-driven approaches to nonlinear systems — phase organisation, pattern formation and statistical signatures of collective states.",
    tags: ["Python", "Simulation", "Data"]
  }
];

export const experience = [
  {
    role: "Project Associate – I",
    organization: "ANRF · SASTRA Deemed University",
    years: "2024 – Present",
    description:
      "Research role in nonlinear dynamics, scientific computing and complex-systems modelling, funded by the Anusandhan National Research Foundation."
  },
  {
    role: "Teaching Assistant",
    organization: "SASTRA Deemed University",
    years: "2022 – 2024",
    description:
      "Supported instruction and research while developing technical communication, mentoring and laboratory skills."
  }
];

export const conferences = [
  {
    title: "Complexity & Nonlinear Dynamics in STEM",
    event: "CNLDS 2023 · IIT Hyderabad",
    date: "05 – 07 June 2023",
    highlight: "Best Poster Award"
  },
  {
    title: "Perspectives in Nonlinear Dynamics",
    event: "PNLD · IIT Madras",
    date: "01 – 04 August 2023",
    highlight: "Participant"
  },
  {
    title: "Conference on Nonlinear Systems & Dynamics",
    event: "CNSD · BDU Trichy",
    date: "10 – 13 March 2025",
    highlight: "Oral Presentation"
  }
];

export const awards = [
  "Best Poster Presentation Award — Complexity and Nonlinear Dynamics in STEM, IIT Hyderabad, 2023"
];

export const references = [
  {
    name: "Dr. V. K. Chandrasekar",
    role: "Associate Professor · School of Electrical & Electronics Engineering",
    institution: "SASTRA Deemed University",
    email: "chandrasekar@eee.sastra.edu"
  },
  {
    name: "Dr. R. Gopal",
    role: "Assistant Professor – II · School of Electrical & Electronics Engineering",
    institution: "SASTRA Deemed University",
    email: "gopal@eee.sastra.edu"
  }
];

import portraitImg from "./assets/portrait.jpg";
import posterImg from "./assets/poster.jpg";
import awardImg from "./assets/award.jpg";

export const images = {
  portrait: portraitImg,
  poster: posterImg,
  award: awardImg
};
