import React, { useState, useMemo, useEffect, createContext, useContext } from "react";
import {
  SplitText, ShinyText, BlurReveal, TiltCard, MagnetButton, ParticleField,
  AuroraBackground, Marquee, Counter, CursorGlow, ScrollProgress,
  motion, AnimatePresence
} from "./animations.jsx";
import {
  profile, navLinks, metrics, marqueeItems, researchInterests, skills, education,
  publications, projects, experience, conferences, references, images
} from "./data.js";

/* ──────────────  Theme context ────────────── */
const ThemeCtx = createContext({ theme: "dark", setTheme: () => {} });
const useTheme = () => useContext(ThemeCtx);

function ThemeProvider({ children }) {
  const [theme, setTheme] = useState(() => {
    if (typeof window === "undefined") return "dark";
    const saved = localStorage.getItem("theme");
    if (saved === "light" || saved === "dark") return saved;
    return window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
  });

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle("light", theme === "light");
    root.classList.toggle("dark", theme === "dark");
    try { localStorage.setItem("theme", theme); } catch (_) {}
  }, [theme]);

  return <ThemeCtx.Provider value={{ theme, setTheme }}>{children}</ThemeCtx.Provider>;
}

/* ──────────────  Inline icons ────────────── */
const I = {
  mail: () => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-10 6L2 7"/></svg>),
  phone: () => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.08 4.18 2 2 0 0 1 4.06 2h3a2 2 0 0 1 2 1.72c.13.96.35 1.89.66 2.78a2 2 0 0 1-.45 2.11L8 9.91a16 16 0 0 0 6.09 6.09l1.3-1.27a2 2 0 0 1 2.11-.45c.89.31 1.82.53 2.78.66A2 2 0 0 1 22 16.92Z"/></svg>),
  pin: () => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4"><path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>),
  arrow: () => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4"><path d="M7 17 17 7"/><path d="M7 7h10v10"/></svg>),
  spark: () => (<svg viewBox="0 0 24 24" fill="currentColor" className="h-3 w-3"><path d="m12 3 1.9 5.8L20 11l-6.1 2.2L12 19l-1.9-5.8L4 11l6.1-2.2Z"/></svg>),
  award: () => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4"><circle cx="12" cy="8" r="6"/><path d="M15.5 13 17 22l-5-3-5 3 1.5-9"/></svg>),
  sun: () => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>),
  moon: () => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79Z"/></svg>),
  // Brand glyphs — official-shape silhouettes
  scholar: () => (
    <svg viewBox="0 0 24 24" fill="currentColor" className="h-4 w-4" aria-hidden>
      <path d="M5.242 13.769 0 9.5 12 0l12 9.5-5.242 4.269C17.548 11.249 14.978 9.5 12 9.5c-2.977 0-5.548 1.748-6.758 4.269ZM12 10a7 7 0 1 0 0 14 7 7 0 0 0 0-14Z"/>
    </svg>
  ),
  orcid: () => (
    <svg viewBox="0 0 24 24" fill="currentColor" className="h-4 w-4" aria-hidden>
      <path d="M12 0C5.372 0 0 5.372 0 12s5.372 12 12 12 12-5.372 12-12S18.628 0 12 0ZM7.369 4.378c.525 0 .947.431.947.947s-.422.947-.947.947a.95.95 0 0 1-.947-.947c0-.516.422-.947.947-.947Zm-.722 3.038h1.444v10.041H6.647V7.416Zm3.562 0h3.9c3.712 0 5.344 2.653 5.344 5.025 0 2.578-2.016 5.025-5.325 5.025h-3.919V7.416Zm1.444 1.303v7.444h2.297c3.272 0 4.022-2.484 4.022-3.722 0-2.016-1.284-3.722-4.097-3.722h-2.222Z"/>
    </svg>
  ),
  github: () => (
    <svg viewBox="0 0 24 24" fill="currentColor" className="h-4 w-4" aria-hidden>
      <path d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.58.1.79-.25.79-.56 0-.28-.01-1.02-.02-2-3.2.7-3.87-1.54-3.87-1.54-.52-1.33-1.27-1.69-1.27-1.69-1.04-.71.08-.7.08-.7 1.15.08 1.76 1.18 1.76 1.18 1.02 1.75 2.69 1.25 3.34.95.1-.74.4-1.25.72-1.54-2.55-.29-5.24-1.28-5.24-5.69 0-1.26.45-2.29 1.18-3.1-.12-.29-.51-1.46.11-3.05 0 0 .97-.31 3.18 1.18a11.07 11.07 0 0 1 5.78 0c2.21-1.49 3.18-1.18 3.18-1.18.62 1.59.23 2.76.11 3.05.74.81 1.18 1.84 1.18 3.1 0 4.42-2.69 5.39-5.26 5.68.41.36.78 1.06.78 2.13 0 1.54-.01 2.78-.01 3.16 0 .31.21.67.8.55C20.22 21.39 23.5 17.07 23.5 12 23.5 5.65 18.35.5 12 .5Z"/>
    </svg>
  )
};

/* ──────────────  Theme toggle button ────────────── */
function ThemeToggle({ className = "" }) {
  const { theme, setTheme } = useTheme();
  const isLight = theme === "light";
  return (
    <button
      aria-label={`Switch to ${isLight ? "dark" : "light"} mode`}
      onClick={() => setTheme(isLight ? "dark" : "light")}
      className={`group relative flex h-10 w-10 items-center justify-center overflow-hidden rounded-full border border-line bg-elev text-fg transition hover:border-accent2/40 ${className}`}
    >
      <AnimatePresence mode="wait" initial={false}>
        <motion.span
          key={theme}
          initial={{ y: -16, opacity: 0, rotate: -45 }}
          animate={{ y: 0, opacity: 1, rotate: 0 }}
          exit={{ y: 16, opacity: 0, rotate: 45 }}
          transition={{ duration: 0.3, ease: [0.2, 0.8, 0.2, 1] }}
          className="flex items-center justify-center"
        >
          {isLight ? <I.moon /> : <I.sun />}
        </motion.span>
      </AnimatePresence>
    </button>
  );
}

/* ──────────────  Top Nav  ────────────── */
function Nav() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className={`fixed left-0 right-0 top-0 z-40 transition-all duration-500 ${scrolled ? "py-3" : "py-5"}`}>
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 md:px-8">
        <a href="#top" className="group flex items-center gap-3">
          <span className="relative flex h-9 w-9 items-center justify-center rounded-full border border-line bg-elev backdrop-blur">
            <span className="font-display text-sm font-bold text-fg">RS</span>
            <span className="absolute inset-0 rounded-full border border-accent2/40 animate-pulse-ring" />
          </span>
          <span className="hidden text-sm font-medium tracking-[0.18em] text-fg/80 md:inline">SENTHAMIZHAN</span>
        </a>

        <nav className="hidden items-center gap-1 rounded-full border border-line bg-elev px-2 py-1.5 backdrop-blur-xl md:flex">
          {navLinks.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="rounded-full px-4 py-1.5 text-sm font-medium text-fg/70 transition hover:bg-fg/5 hover:text-fg"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          <ThemeToggle />
          <MagnetButton
            href={`mailto:${profile.email}`}
            className="inline-flex items-center gap-2 rounded-full bg-fg px-5 py-2.5 text-sm font-bold text-bg transition hover:bg-accent2 hover:text-bg"
          >
            Get in touch <I.arrow />
          </MagnetButton>
        </div>

        <div className="flex items-center gap-2 md:hidden">
          <ThemeToggle />
          <button
            aria-label="Menu"
            onClick={() => setOpen(!open)}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-line bg-elev backdrop-blur"
          >
            <div className="flex flex-col gap-1.5">
              <span className={`h-[1.5px] w-5 bg-fg transition ${open ? "translate-y-2 rotate-45" : ""}`} />
              <span className={`h-[1.5px] w-5 bg-fg transition ${open ? "opacity-0" : ""}`} />
              <span className={`h-[1.5px] w-5 bg-fg transition ${open ? "-translate-y-2 -rotate-45" : ""}`} />
            </div>
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="mx-5 mt-3 rounded-2xl border border-line bg-elev p-4 backdrop-blur-xl md:hidden"
          >
            {navLinks.map((l) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className="block rounded-xl px-3 py-2.5 text-base font-medium text-fg/85 hover:bg-fg/5"
              >
                {l.label}
              </a>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

/* ──────────────  Hero  ────────────── */
function Hero() {
  const { theme } = useTheme();
  return (
    <section id="top" className="relative overflow-hidden pb-20 pt-32 md:pb-28 md:pt-40">
      <ParticleField density={70} hue={theme === "light" ? "215,75%,45%" : "180,80%,75%"} />

      <div className="relative mx-auto max-w-7xl px-5 md:px-8">
        <div className="grid gap-12 md:grid-cols-[minmax(0,1fr)_18rem] md:gap-12 lg:grid-cols-[minmax(0,1fr)_22rem] lg:gap-16">
          <div className="relative">
            <BlurReveal>
              <div className="mb-7 inline-flex items-center gap-2 rounded-full border border-line bg-fg/5 px-4 py-2 text-xs font-medium uppercase tracking-[0.28em] text-fg/75 backdrop-blur">
                <span className="relative flex h-2 w-2">
                  <span className="absolute h-full w-full animate-ping rounded-full bg-accent2 opacity-75" />
                  <span className="relative h-2 w-2 rounded-full bg-accent2" />
                </span>
                ANRF Project Associate · Open to research collaborations
              </div>
            </BlurReveal>

            <h1 className="font-display text-[clamp(3.4rem,9.5vw,9rem)] font-light leading-[0.92] tracking-[-0.05em] text-fg">
              <SplitText className="block italic" delay={0.1} stagger={0.025}>
                Senthamizhan
              </SplitText>
              <SplitText className="block" delay={0.45} stagger={0.025}>
                R.
              </SplitText>
            </h1>

            <BlurReveal delay={0.85}>
              <div className="mt-8 max-w-xl border-l-2 border-accent pl-5">
                <p className="font-mono text-xs uppercase tracking-[0.22em] text-accent">
                  {profile.heroTimeline}
                </p>
                <p className="mt-3 text-lg leading-7 text-fg/80 md:text-xl md:leading-8">
                  Working at the intersection of <ShinyText>nonlinear dynamics</ShinyText> and mathematical physics — exploring how swarms of oscillators sync, frustrate and self-organise.
                </p>
              </div>
            </BlurReveal>

            <BlurReveal delay={1.05}>
              <div className="mt-10 flex flex-wrap items-center gap-4">
                <MagnetButton
                  href="#publications"
                  className="group inline-flex items-center gap-2 rounded-full bg-fg px-7 py-3.5 text-sm font-bold text-bg transition hover:bg-accent2"
                >
                  Read the papers
                  <span className="transition-transform group-hover:translate-x-1"><I.arrow /></span>
                </MagnetButton>
                <MagnetButton
                  href="#contact"
                  className="inline-flex items-center gap-2 rounded-full border border-line bg-fg/5 px-7 py-3.5 text-sm font-bold text-fg backdrop-blur transition hover:bg-fg/10"
                >
                  Contact
                </MagnetButton>
              </div>
            </BlurReveal>

            <BlurReveal delay={1.2}>
              <div className="mt-12 flex flex-wrap items-center gap-x-8 gap-y-3 text-sm text-fg/55">
                <span className="flex items-center gap-2"><I.pin /> {profile.location}</span>
                <span className="flex items-center gap-2"><I.mail /> {profile.email}</span>
              </div>
            </BlurReveal>

            {/* Identity links: Scholar / ORCID / GitHub */}
            <BlurReveal delay={1.35}>
              <div className="mt-6 flex flex-wrap items-center gap-3">
                <a
                  href={profile.scholar}
                  target="_blank"
                  rel="noreferrer"
                  className="group inline-flex items-center gap-2 rounded-full border border-line bg-fg/[0.04] px-4 py-2 text-xs font-bold uppercase tracking-[0.18em] text-fg/75 transition hover:border-accent2/50 hover:text-fg"
                >
                  <I.scholar /> Google Scholar
                  <span className="text-fg/40 transition group-hover:translate-x-0.5 group-hover:text-accent2"><I.arrow /></span>
                </a>
                <a
                  href={profile.orcid}
                  target="_blank"
                  rel="noreferrer"
                  className="group inline-flex items-center gap-2 rounded-full border border-line bg-fg/[0.04] px-4 py-2 text-xs font-bold uppercase tracking-[0.18em] text-fg/75 transition hover:border-[#A6CE39]/60 hover:text-fg"
                >
                  <span className="text-[#A6CE39]"><I.orcid /></span> ORCID
                  <span className="text-fg/40 transition group-hover:translate-x-0.5"><I.arrow /></span>
                </a>
                <a
                  href={profile.github}
                  target="_blank"
                  rel="noreferrer"
                  className="group inline-flex items-center gap-2 rounded-full border border-line bg-fg/[0.04] px-4 py-2 text-xs font-bold uppercase tracking-[0.18em] text-fg/75 transition hover:border-fg/50 hover:text-fg"
                >
                  <I.github /> GitHub
                  <span className="text-fg/40 transition group-hover:translate-x-0.5"><I.arrow /></span>
                </a>
              </div>
            </BlurReveal>
          </div>

          {/* Portrait card — labels & best-poster tag removed */}
          <div className="relative flex items-center justify-center">
            <BlurReveal delay={0.5} className="w-full">
              <TiltCard className="relative mx-auto w-full max-w-[20rem] sm:max-w-[22rem] md:max-w-none">
                <div className="relative overflow-hidden rounded-[2.2rem] border border-line bg-fg/5 shadow-[0_30px_80px_-20px_rgba(0,0,0,0.6)]">
                  <img
                    src={images.portrait}
                    alt="R. Senthamizhan portrait"
                    className="aspect-[4/5] w-full object-cover"
                    style={{ filter: "contrast(1.05) saturate(1.05)" }}
                  />
                  {/* Subtle gradient overlay (kept for finish, no labels) */}
                  <div className="absolute inset-0 bg-gradient-to-t from-bg/40 via-transparent to-transparent" />
                  {/* Corner brackets */}
                  <div className="absolute left-4 top-4 h-7 w-7 border-l-2 border-t-2 border-fg/60" />
                  <div className="absolute right-4 top-4 h-7 w-7 border-r-2 border-t-2 border-fg/60" />
                  <div className="absolute bottom-4 left-4 h-7 w-7 border-b-2 border-l-2 border-fg/60" />
                  <div className="absolute bottom-4 right-4 h-7 w-7 border-b-2 border-r-2 border-fg/60" />
                </div>
              </TiltCard>
            </BlurReveal>
          </div>
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.6, duration: 0.6 }}
        className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 md:flex"
      >
        <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-fg/50">scroll</span>
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 1.6, repeat: Infinity }}
          className="h-8 w-[1px] bg-gradient-to-b from-fg/60 to-transparent"
        />
      </motion.div>
    </section>
  );
}

/* ──────────────  Marquee strip  ────────────── */
function MarqueeStrip() {
  return (
    <section className="relative border-y border-line bg-bg py-10">
      <Marquee items={marqueeItems} />
    </section>
  );
}

/* ──────────────  Metric grid  ────────────── */
function Metrics() {
  return (
    <section className="relative mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-28">
      <div className="grid grid-cols-2 gap-px overflow-hidden rounded-[2rem] border border-line bg-line md:grid-cols-4">
        {metrics.map((m, i) => (
          <BlurReveal key={m.label} delay={i * 0.1}>
            <div className="group relative h-full bg-bg p-8 transition hover:bg-fg/5 md:p-10">
              <div className="font-mono text-[10px] uppercase tracking-[0.28em] text-accent2">
                / 0{i + 1}
              </div>
              <div className="mt-4 font-display text-5xl font-light tracking-tight text-fg md:text-7xl">
                <Counter value={m.value} />
              </div>
              <div className="mt-3 max-w-[12rem] text-sm leading-5 text-fg/60">
                {m.label}
              </div>
              <div className="absolute bottom-0 left-0 h-[2px] w-0 bg-accent transition-all duration-700 group-hover:w-full" />
            </div>
          </BlurReveal>
        ))}
      </div>
    </section>
  );
}

/* ──────────────  Section header  ────────────── */
function SectionHeader({ eyebrow, title, lead, n }) {
  return (
    <div className="mb-14 grid gap-8 md:grid-cols-[auto_1fr] md:gap-16">
      <div className="flex items-start gap-3">
        <span className="font-mono text-xs uppercase tracking-[0.3em] text-accent">/ {n}</span>
      </div>
      <div>
        <BlurReveal>
          <p className="font-mono text-xs uppercase tracking-[0.3em] text-fg/55">{eyebrow}</p>
        </BlurReveal>
        <h2 className="mt-4 font-display text-[clamp(2.5rem,6.5vw,5.5rem)] font-light leading-[0.95] tracking-[-0.04em] text-fg">
          <SplitText>{title}</SplitText>
        </h2>
        {lead && (
          <BlurReveal delay={0.3}>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-fg/65">{lead}</p>
          </BlurReveal>
        )}
      </div>
    </div>
  );
}

/* ──────────────  Research  ────────────── */
function Research() {
  return (
    <section id="research" className="relative mx-auto max-w-7xl scroll-mt-24 px-5 py-24 md:px-8 md:py-32">
      <SectionHeader
        n="01"
        eyebrow="Research focus"
        title="Synchrony, swarms & complex systems."
        lead={profile.summary}
      />

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {researchInterests.map((topic, i) => (
          <BlurReveal key={topic} delay={i * 0.05}>
            <TiltCard intensity={5} className="group h-full rounded-3xl border border-line bg-fg/[0.03] p-7 transition hover:border-accent2/40 hover:bg-fg/[0.05]">
              <div className="flex items-start justify-between">
                <span className="font-mono text-[10px] uppercase tracking-[0.28em] text-fg/45">
                  topic / {String(i + 1).padStart(2, "0")}
                </span>
                <span className="text-accent transition group-hover:translate-x-1 group-hover:-translate-y-1">
                  <I.arrow />
                </span>
              </div>
              <h3 className="mt-6 font-display text-2xl font-light leading-tight text-fg md:text-3xl">
                {topic}
              </h3>
              <div className="mt-6 flex items-center gap-2">
                <span className="h-[1px] w-8 bg-fg/30" />
                <span className="text-xs font-medium uppercase tracking-[0.18em] text-fg/40">
                  area
                </span>
              </div>
            </TiltCard>
          </BlurReveal>
        ))}
      </div>

      {/* Poster image strip + /now panel */}
      <BlurReveal delay={0.2}>
        <div className="mt-16 grid gap-6 md:grid-cols-[2fr_1fr]">
          <div className="relative overflow-hidden rounded-[2rem] border border-line">
            <img src={images.poster} alt="Poster presentation at conference" className="aspect-[16/10] w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-tr from-bg/85 via-bg/20 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-7">
              <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-accent2">
                / poster presentation · CNLDS 2023
              </p>
              <p className="mt-2 max-w-md font-display text-2xl italic leading-tight text-fg md:text-3xl">
                Influence of higher-order harmonics in swarmalators
              </p>
            </div>
          </div>
          <div className="rounded-[2rem] border border-line bg-fg/[0.04] p-7">
            <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-fg/55">/ now</p>
            <p className="mt-3 text-sm leading-6 text-fg/75">
              Project Associate – I funded by ANRF, exploring swarmalator dynamics and computational complex systems.
            </p>
          </div>
        </div>
      </BlurReveal>
    </section>
  );
}

/* ──────────────  Publications  ────────────── */
function Publications() {
  const [filter, setFilter] = useState("All");
  const filters = ["All", "PRE", "CSF"];
  const list = useMemo(
    () => (filter === "All" ? publications : publications.filter((p) => p.tag === filter)),
    [filter]
  );

  return (
    <section id="publications" className="relative mx-auto max-w-7xl scroll-mt-24 px-5 py-24 md:px-8 md:py-32">
      <SectionHeader
        n="02"
        eyebrow="Selected papers"
        title="Peer-reviewed publications."
        lead="Research articles in physics and complex-systems journals on swarmalator dynamics, harmonics and frustration-driven phenomena."
      />

      <div className="mb-10 flex flex-wrap items-center gap-2">
        {filters.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`rounded-full border px-4 py-1.5 text-xs font-bold uppercase tracking-[0.2em] transition ${
              filter === f
                ? "border-accent bg-accent text-bg"
                : "border-line bg-fg/[0.03] text-fg/70 hover:border-fg/30"
            }`}
          >
            {f}
          </button>
        ))}
        <span className="ml-2 font-mono text-xs text-fg/40">
          {list.length} {list.length === 1 ? "paper" : "papers"}
        </span>
      </div>

      <div className="overflow-hidden rounded-[2rem] border border-line bg-fg/[0.02]">
        <AnimatePresence mode="popLayout">
          {list.map((p, i) => (
            <motion.a
              key={p.doi}
              href={p.href}
              target="_blank"
              rel="noreferrer"
              layout
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.5, ease: [0.2, 0.8, 0.2, 1], delay: i * 0.05 }}
              className="group relative flex flex-col gap-5 border-b border-line p-7 transition last:border-0 hover:bg-fg/[0.04] md:flex-row md:items-center md:gap-8 md:p-9"
            >
              <div className="flex shrink-0 items-center gap-5 md:w-44">
                <div className="font-display text-5xl font-light tracking-tight text-fg/30 group-hover:text-accent transition md:text-6xl">
                  {p.year}
                </div>
              </div>
              <div className="flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="rounded-full border border-accent2/30 bg-accent2/10 px-2.5 py-0.5 font-mono text-[10px] font-bold uppercase tracking-[0.2em] text-accent2">
                    {p.tag}
                  </span>
                  <span className="rounded-full border border-line bg-fg/5 px-2.5 py-0.5 text-[10px] font-medium uppercase tracking-[0.2em] text-fg/60">
                    {p.status}
                  </span>
                </div>
                <h3 className="mt-3 font-display text-2xl font-light leading-snug tracking-tight text-fg group-hover:text-accent2 md:text-3xl">
                  {p.title}
                </h3>
                <p className="mt-3 text-sm text-fg/55">{p.authors}</p>
                <p className="mt-1 font-mono text-xs text-fg/45">
                  {p.venue} · {p.cite} · DOI {p.doi}
                </p>
              </div>
              <div className="hidden shrink-0 md:block">
                <span className="flex h-12 w-12 items-center justify-center rounded-full border border-line bg-fg/5 text-fg/70 transition group-hover:bg-accent group-hover:border-accent group-hover:text-bg group-hover:rotate-[-12deg]">
                  <I.arrow />
                </span>
              </div>
            </motion.a>
          ))}
        </AnimatePresence>
      </div>
    </section>
  );
}

/* ──────────────  Projects  ────────────── */
function Projects() {
  return (
    <section id="projects" className="relative mx-auto max-w-7xl scroll-mt-24 px-5 py-24 md:px-8 md:py-32">
      <SectionHeader
        n="03"
        eyebrow="Selected projects"
        title="Work in progress."
        lead="Research threads currently in motion — theoretical and data-driven explorations of synchronization, harmonics and collective behaviour."
      />

      <div className="grid gap-6 md:grid-cols-2">
        {projects.map((proj, i) => (
          <BlurReveal key={proj.n} delay={i * 0.08}>
            <TiltCard intensity={6} className="group relative h-full overflow-hidden rounded-3xl border border-line bg-fg/[0.03] p-7 transition hover:border-accent/40">
              <div className="absolute inset-0 -z-10 opacity-0 transition group-hover:opacity-100">
                <div className="h-full w-full bg-gradient-to-br from-accent2/5 via-transparent to-accent/8" />
              </div>
              <div className="flex items-start justify-between">
                <span className="font-display text-5xl font-light italic text-fg/25">{proj.n}</span>
                <span className="rounded-full border border-line bg-fg/5 px-3 py-1 font-mono text-[10px] uppercase tracking-[0.2em] text-fg/65">
                  ongoing
                </span>
              </div>
              <h3 className="mt-7 font-display text-2xl font-light leading-tight text-fg">
                {proj.title}
              </h3>
              <p className="mt-4 text-sm leading-6 text-fg/65">{proj.description}</p>
              <div className="mt-6 flex flex-wrap gap-2">
                {proj.tags.map((t) => (
                  <span key={t} className="rounded-full border border-line bg-fg/[0.04] px-2.5 py-1 text-[11px] font-medium text-fg/65">
                    {t}
                  </span>
                ))}
              </div>
            </TiltCard>
          </BlurReveal>
        ))}
      </div>
    </section>
  );
}

/* ──────────────  CV section  ────────────── */
function CV() {
  return (
    <section id="cv" className="relative mx-auto max-w-7xl scroll-mt-24 px-5 py-24 md:px-8 md:py-32">
      <SectionHeader
        n="04"
        eyebrow="Curriculum vitae"
        title="The full record."
        lead="Education, experience, talks and recognitions — everything that shaped the path."
      />

      <div className="grid gap-6 lg:grid-cols-2">
        <BlurReveal>
          <div className="rounded-[2rem] border border-line bg-fg/[0.03] p-7 md:p-9">
            <div className="mb-7 flex items-center gap-3">
              <span className="h-2 w-2 rounded-full bg-accent2" />
              <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-fg/55">/ education</p>
            </div>
            <div className="space-y-8">
              {education.map((e) => (
                <div key={e.degree} className="relative pl-7">
                  <span className="absolute left-0 top-2 h-2 w-2 rounded-full bg-accent" />
                  <span className="absolute left-[3.5px] top-4 h-full w-px bg-line" />
                  <p className="font-mono text-xs text-fg/50">{e.years}</p>
                  <h4 className="mt-1 font-display text-xl font-light text-fg md:text-2xl">{e.degree}</h4>
                  <p className="mt-1 text-sm font-medium text-accent2">{e.institution}</p>
                  <p className="mt-2 font-mono text-xs text-fg/55">{e.score}</p>
                  <p className="mt-3 text-sm leading-6 text-fg/60">{e.details}</p>
                </div>
              ))}
            </div>
          </div>
        </BlurReveal>

        <BlurReveal delay={0.1}>
          <div className="rounded-[2rem] border border-line bg-fg/[0.03] p-7 md:p-9">
            <div className="mb-7 flex items-center gap-3">
              <span className="h-2 w-2 rounded-full bg-accent" />
              <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-fg/55">/ experience</p>
            </div>
            <div className="space-y-8">
              {experience.map((e) => (
                <div key={e.role} className="relative pl-7">
                  <span className="absolute left-0 top-2 h-2 w-2 rounded-full bg-accent2" />
                  <span className="absolute left-[3.5px] top-4 h-full w-px bg-line" />
                  <p className="font-mono text-xs text-fg/50">{e.years}</p>
                  <h4 className="mt-1 font-display text-xl font-light text-fg md:text-2xl">{e.role}</h4>
                  <p className="mt-1 text-sm font-medium text-accent">{e.organization}</p>
                  <p className="mt-3 text-sm leading-6 text-fg/60">{e.description}</p>
                </div>
              ))}
            </div>
          </div>
        </BlurReveal>
      </div>

      {/* Award + conferences */}
      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_1.2fr]">
        <BlurReveal>
          <TiltCard intensity={4} className="relative overflow-hidden rounded-[2rem] border border-line">
            <img src={images.award} alt="Best poster award ceremony" className="aspect-[4/3] w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-bg/90 via-bg/30 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-7">
              <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-accent/40 bg-accent/10 px-3 py-1 backdrop-blur">
                <I.award />
                <span className="font-mono text-[10px] font-bold uppercase tracking-[0.22em] text-accent">
                  Best Poster Award
                </span>
              </div>
              <p className="font-display text-2xl italic leading-tight text-fg md:text-3xl">
                CNLDS 2023 — IIT Hyderabad
              </p>
              <p className="mt-2 text-sm text-fg/65">
                For research on higher-order harmonics in swarmalators.
              </p>
            </div>
          </TiltCard>
        </BlurReveal>

        <BlurReveal delay={0.1}>
          <div className="h-full rounded-[2rem] border border-line bg-fg/[0.03] p-7 md:p-9">
            <div className="mb-7 flex items-center gap-3">
              <span className="h-2 w-2 rounded-full bg-accent3" />
              <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-fg/55">/ conferences</p>
            </div>
            <div className="space-y-5">
              {conferences.map((c) => (
                <div key={c.title} className="group flex items-start gap-5 rounded-2xl border border-line bg-fg/[0.03] p-5 transition hover:border-accent2/30 hover:bg-fg/[0.05]">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-line bg-fg/5 font-mono text-xs text-fg/70">
                    <I.spark />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="font-display text-lg font-light text-fg md:text-xl">{c.title}</p>
                    <p className="mt-1 text-sm text-fg/65">{c.event}</p>
                    <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1">
                      <span className="font-mono text-xs text-fg/45">{c.date}</span>
                      <span className="text-fg/30">·</span>
                      <span className="text-xs font-bold uppercase tracking-[0.18em] text-accent2">{c.highlight}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </BlurReveal>
      </div>

      {/* Skills + References */}
      <div className="mt-6 grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
        <BlurReveal>
          <div className="h-full rounded-[2rem] border border-line bg-fg/[0.03] p-7 md:p-9">
            <div className="mb-7 flex items-center gap-3">
              <span className="h-2 w-2 rounded-full bg-accent2" />
              <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-fg/55">/ technical skills</p>
            </div>
            <div className="space-y-6">
              {skills.map((s) => (
                <div key={s.group}>
                  <p className="font-display text-lg font-light italic text-fg md:text-xl">{s.group}</p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {s.items.map((it) => (
                      <span key={it} className="rounded-full border border-line bg-fg/[0.04] px-3 py-1.5 text-xs font-medium text-fg/75">
                        {it}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </BlurReveal>

        <BlurReveal delay={0.1}>
          <div className="h-full rounded-[2rem] border border-line bg-fg/[0.03] p-7 md:p-9">
            <div className="mb-7 flex items-center gap-3">
              <span className="h-2 w-2 rounded-full bg-accent" />
              <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-fg/55">/ references</p>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              {references.map((r) => (
                <div key={r.email} className="rounded-2xl border border-line bg-fg/[0.04] p-5 transition hover:border-accent2/30">
                  <p className="font-display text-lg font-light text-fg">{r.name}</p>
                  <p className="mt-1 text-xs leading-5 text-fg/55">{r.role}</p>
                  <p className="mt-2 text-xs text-fg/60">{r.institution}</p>
                  <a href={`mailto:${r.email}`} className="mt-3 inline-flex items-center gap-1.5 text-xs font-bold text-accent2 hover:text-accent">
                    <I.mail /> {r.email}
                  </a>
                </div>
              ))}
            </div>
          </div>
        </BlurReveal>
      </div>
    </section>
  );
}

/* ──────────────  Contact (no duplicate award card) ────────────── */
function Contact() {
  return (
    <section id="contact" className="relative mx-auto max-w-7xl scroll-mt-24 px-5 py-24 md:px-8 md:py-32">
      <SectionHeader
        n="05"
        eyebrow="Get in touch"
        title="Let's talk research."
      />

      <BlurReveal>
        <div className="overflow-hidden rounded-[2.5rem] border border-line bg-fg/[0.03] p-8 md:p-12">
          <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-accent">
            / open to research conversations
          </p>
          <h3 className="mt-5 max-w-3xl font-display text-[clamp(2rem,4vw,3.6rem)] font-light leading-[1] tracking-[-0.03em] text-fg">
            Interested in <span className="italic text-shimmer">nonlinear dynamics</span>, synchronization or complex systems?
          </h3>
          <p className="mt-6 max-w-xl leading-7 text-fg/70">
            I welcome conversations about collaborative research, conference presentations, computational modelling and academic opportunities.
          </p>

          <div className="mt-10 grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            <MagnetButton
              href={`mailto:${profile.email}`}
              className="group flex min-w-0 items-center gap-3 rounded-2xl border border-line bg-fg/[0.04] p-5 font-medium text-fg transition hover:border-accent2/50 hover:bg-fg/[0.07]"
            >
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-accent2/15 text-accent2"><I.mail /></span>
              <div className="min-w-0">
                <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-fg/45">primary email</p>
                <p className="truncate text-sm">{profile.email}</p>
              </div>
            </MagnetButton>
            <MagnetButton
              href={`tel:${profile.phone.replace(/\s/g, "")}`}
              className="flex items-center gap-3 rounded-2xl border border-line bg-fg/[0.04] p-5 font-medium text-fg transition hover:border-accent/50 hover:bg-fg/[0.07]"
            >
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-accent/15 text-accent"><I.phone /></span>
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-fg/45">phone</p>
                <p className="text-sm">{profile.phone}</p>
              </div>
            </MagnetButton>
            <div className="flex items-center gap-3 rounded-2xl border border-line bg-fg/[0.04] p-5 font-medium text-fg">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-accent3/15 text-accent3"><I.pin /></span>
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-fg/45">location</p>
                <p className="text-sm">{profile.location}</p>
              </div>
            </div>
          </div>

          {/* Identity links row */}
          <div className="mt-6 grid gap-3 md:grid-cols-3">
            <MagnetButton
              href={profile.scholar}
              target="_blank"
              rel="noreferrer"
              className="group flex items-center gap-3 rounded-2xl border border-line bg-fg/[0.04] p-5 font-medium text-fg transition hover:border-accent2/50 hover:bg-fg/[0.07]"
            >
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-accent2/15 text-accent2"><I.scholar /></span>
              <div className="min-w-0">
                <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-fg/45">google scholar</p>
                <p className="truncate text-sm">qr-JN2cAAAAJ</p>
              </div>
              <span className="ml-auto text-fg/40 transition group-hover:translate-x-0.5 group-hover:text-accent2"><I.arrow /></span>
            </MagnetButton>
            <MagnetButton
              href={profile.orcid}
              target="_blank"
              rel="noreferrer"
              className="group flex items-center gap-3 rounded-2xl border border-line bg-fg/[0.04] p-5 font-medium text-fg transition hover:border-[#A6CE39]/60 hover:bg-fg/[0.07]"
            >
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#A6CE39]/15 text-[#A6CE39]"><I.orcid /></span>
              <div className="min-w-0">
                <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-fg/45">orcid</p>
                <p className="truncate text-sm">0009-0000-0669-3336</p>
              </div>
              <span className="ml-auto text-fg/40 transition group-hover:translate-x-0.5"><I.arrow /></span>
            </MagnetButton>
            <MagnetButton
              href={profile.github}
              target="_blank"
              rel="noreferrer"
              className="group flex items-center gap-3 rounded-2xl border border-line bg-fg/[0.04] p-5 font-medium text-fg transition hover:border-fg/50 hover:bg-fg/[0.07]"
            >
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-fg/15 text-fg"><I.github /></span>
              <div className="min-w-0">
                <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-fg/45">github</p>
                <p className="truncate text-sm">@senthamizhanR</p>
              </div>
              <span className="ml-auto text-fg/40 transition group-hover:translate-x-0.5"><I.arrow /></span>
            </MagnetButton>
          </div>
        </div>
      </BlurReveal>
    </section>
  );
}

/* ──────────────  Footer  ────────────── */
function Footer() {
  return (
    <footer className="relative border-t border-line bg-bg">
      <div className="mx-auto max-w-7xl px-5 py-16 md:px-8 md:py-20">
        <div className="font-display text-[clamp(3rem,9vw,9rem)] font-light leading-[0.92] tracking-[-0.05em] text-fg/95">
          <span className="italic">Senthamizhan</span> R.
        </div>
        <div className="mt-8 grid gap-6 border-t border-line pt-8 md:grid-cols-4">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-fg/45">/ research</p>
            <p className="mt-2 text-sm text-fg/70">Nonlinear dynamics · Mathematical physics · Swarmalators</p>
          </div>
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-fg/45">/ contact</p>
            <a href={`mailto:${profile.email}`} className="mt-2 block text-sm text-fg/70 hover:text-accent2">{profile.email}</a>
            <a href={`mailto:${profile.altEmail}`} className="block text-sm text-fg/55 hover:text-accent2">{profile.altEmail}</a>
          </div>
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-fg/45">/ identity</p>
            <div className="mt-2 flex items-center gap-3 text-fg/70">
              <a href={profile.scholar} target="_blank" rel="noreferrer" aria-label="Google Scholar" className="transition hover:text-accent2"><I.scholar /></a>
              <a href={profile.orcid} target="_blank" rel="noreferrer" aria-label="ORCID" className="transition hover:text-[#A6CE39]"><I.orcid /></a>
              <a href={profile.github} target="_blank" rel="noreferrer" aria-label="GitHub" className="transition hover:text-fg"><I.github /></a>
            </div>
          </div>
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-fg/45">/ © {new Date().getFullYear()}</p>
            <p className="mt-2 text-sm text-fg/55">Built with React · Framer Motion · Tailwind</p>
          </div>
        </div>
      </div>
    </footer>
  );
}

/* ──────────────  App  ────────────── */
export default function App() {
  return (
    <ThemeProvider>
      <main className="relative min-h-screen overflow-x-hidden bg-bg text-fg transition-colors duration-300">
        <AuroraBackground />
        <CursorGlow />
        <ScrollProgress />
        <Nav />
        <Hero />
        <MarqueeStrip />
        <Metrics />
        <Research />
        <Publications />
        <Projects />
        <CV />
        <Contact />
        <Footer />
      </main>
    </ThemeProvider>
  );
}
